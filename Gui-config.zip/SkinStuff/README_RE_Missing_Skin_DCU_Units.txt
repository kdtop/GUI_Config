NOTE:

The skinning package is propriatary.  I put the *.dcu files into a zip file (SkinStuff.zip) to bring this point to the attention of those recompiling the code.  Please read the license for these files, found in license.txt

To use the files, simply unzip them into this same folder.
