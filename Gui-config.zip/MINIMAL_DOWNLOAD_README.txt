To download just the application without the source, download just the following:
-- GUI-config.exe
-- qtintf70.dll
-- KIDS Server Path (directory)
-- SkinStuff\skins (directory)
    (You don't need the .zip file in SkinStuff unless you are recompiling)